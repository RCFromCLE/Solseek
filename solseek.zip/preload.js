const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
    // Load saved accounts
    loadAccounts: () => ipcRenderer.invoke('get-saved-accounts'),

    // Save account details
    saveAccount: (accountData) => ipcRenderer.invoke('save-account', accountData),

    // Delete account
    deleteAccount: (address) => ipcRenderer.invoke('delete-account', address),

    // Place a trade
    placeTrade: (tradeDetails) => ipcRenderer.invoke('place-trade', tradeDetails),

    // Get balance for an account
    getBalance: (isProduction, address) => ipcRenderer.invoke('get-balance', isProduction, address),

    // Request development SOL from a faucet
    requestDevSol: (address) => ipcRenderer.invoke('request-dev-sol', address),

    // Run backtest simulation
    performBacktest: () => ipcRenderer.invoke('perform-backtest'),

    // Start live testing
    startLiveTest: () => ipcRenderer.invoke('start-live-test')
});