const { fetchHistoricalData, fetchLiveData } = require('./marketData');
const { calculateIndicators } = require('./indicators');

async function performBacktest() {
    const data = await fetchHistoricalData();
    const indicators = calculateIndicators(data.map(d => d.price));
    return indicators;
}

async function startLiveTest() {
    const data = await fetchLiveData();
    const indicators = calculateIndicators([data.price]);
    return indicators;
}

module.exports = { performBacktest, startLiveTest };
